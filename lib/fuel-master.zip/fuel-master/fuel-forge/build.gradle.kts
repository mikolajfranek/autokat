dependencies {
    api(project(Fuel.name))

    implementation(Forge.dependency)

    testImplementation(project(Fuel.Test.name))
}
