# Changelog

The changelog for [Fuel](https://github.com/kittinunf/Fuel/) is located at the [releases](https://github.com/kittinunf/Fuel/releases) page.
