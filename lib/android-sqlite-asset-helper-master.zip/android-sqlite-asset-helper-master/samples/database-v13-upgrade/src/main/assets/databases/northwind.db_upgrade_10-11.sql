-- nothing
INSERT INTO upgrades VALUES (11, "this;that");