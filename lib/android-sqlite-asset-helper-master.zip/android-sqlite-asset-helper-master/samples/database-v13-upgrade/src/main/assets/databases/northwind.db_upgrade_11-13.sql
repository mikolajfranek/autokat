-- nothing
INSERT INTO upgrades VALUES (13, "this;that");