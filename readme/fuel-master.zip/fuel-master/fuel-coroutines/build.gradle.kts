dependencies {
    api(project(Fuel.name))

    api(KotlinX.Coroutines.jvm)

    testImplementation(project(Fuel.Test.name))
}
