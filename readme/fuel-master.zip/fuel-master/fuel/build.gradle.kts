dependencies {
    api(Result.dependency)

    testImplementation(project(Fuel.Test.name))
    testImplementation(Json.dependency)
}
