dependencies {
    api(project(Fuel.name))

    implementation(Gson.dependency)

    testImplementation(project(Fuel.Test.name))
}
