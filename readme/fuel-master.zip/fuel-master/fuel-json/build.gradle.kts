dependencies {
    api(project(Fuel.name))

    implementation(Json.dependency)

    testImplementation(project(Fuel.Test.name))
}
