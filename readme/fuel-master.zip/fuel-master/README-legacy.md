# Fuel

[![Kotlin](https://img.shields.io/badge/Kotlin-1.3.0-blue.svg)](https://kotlinlang.org) 
[![bintray](https://api.bintray.com/packages/kittinunf/maven/Fuel-Android/images/download.svg)](https://bintray.com/kittinunf/maven/Fuel-Android/_latestVersion) 
[![Build Status](https://travis-ci.org/kittinunf/Fuel.svg?branch=master)](https://travis-ci.org/kittinunf/Fuel)
[![Codecov](https://codecov.io/github/kittinunf/Fuel/coverage.svg?branch=master)](https://codecov.io/gh/kittinunf/Fuel)

The easiest HTTP networking library for Kotlin/Android.

## Features

- [x] Support basic HTTP GET/POST/PUT/DELETE/HEAD/PATCH in a fluent style interface
- [x] Support both asynchronous and blocking requests
- [x] Download file
- [x] Upload file (multipart/form-data)
- [x] Cancel in-flight request
- [x] Request timeout
- [x] Configuration manager by using `FuelManager`
- [x] Debug log / cUrl log
- [x] Support response deserialization into plain old object (both Kotlin & Java)
- [x] Automatically invoke handler on Android Main Thread when using Android Module
- [x] Special test mode for easier testing
- [x] Support for reactive programming via RxJava 2.x and Project Reactor 3.x
- [x] Google Components [LiveData](https://developer.android.com/topic/libraries/architecture/livedata.html) support
- [x] Built-in object serialization module (kotlinx-serialization, Gson, Jackson, Moshi, Forge) :sparkles:
- [x] Support Kotlin's [Coroutines](https://github.com/Kotlin/kotlinx.coroutines) module
- [x] API Routing

## Installation

### There are 2 versions of Fuel build against different Kotlin Versions 

#### [![Download](https://api.bintray.com/packages/kittinunf/maven/Fuel-Android/images/download.svg?version=1.15.1)](https://bintray.com/kittinunf/maven/Fuel-Android/1.15.1/link)
* Kotlin - 1.2.71
* Coroutine - 0.23.3

#### [![Download](https://api.bintray.com/packages/kittinunf/maven/Fuel-Android/images/download.svg?version=1.16.0)](https://bintray.com/kittinunf/maven/Fuel-Android/1.16.0/link)
* Kotlin - 1.3.0-rc-146
* Coroutine - 0.30.1-eap13

### Dependency - fuel

* [Result](https://github.com/kittinunf/Result) - The modelling for success/failure of operations in Kotlin

### Dependency - fuel-android

* [Android SDK](https://developer.android.com/studio/index.html) - Android SDK
* Min SDK: 19 

### Dependency - fuel-livedata

* [Live Data](https://developer.android.com/topic/libraries/architecture/livedata.html) - Android Architecture Components - LiveData

### Dependency - fuel-rxjava

* [RxJava](https://github.com/ReactiveX/RxJava) - RxJava – Reactive Extensions for the JVM

### Dependency - fuel-coroutines

* [Coroutines](https://github.com/Kotlin/kotlinx.coroutines) - Kotlin Coroutines - Library support for Kotlin coroutines

### Dependency - fuel-kotlinx-serialization

* [Kotlinx Serialization](https://github.com/Kotlin/kotlinx.serialization) - Kotlinx Serialization - Kotlin cross-platform / multi-format serialization

### Dependency - fuel-gson

* [Gson](https://github.com/google/gson) - Gson - A Java serialization/deserialization library to convert Java Objects into JSON and back

### Dependency - fuel-jackson

* [Jackson](https://github.com/FasterXML/jackson-module-kotlin) - Jackson - The JSON library for Java

### Dependency - fuel-moshi

* [Moshi](https://github.com/square/moshi) - Moshi - A modern JSON library for Android and Java

### Dependency - fuel-forge

* [Forge](https://github.com/kittinunf/Forge/) - Forge - Functional style JSON parsing written in Kotlin

### Dependency - fuel-reactor

* [Project Reactor](https://github.com/reactor/reactor-core) - Project Reactor - Implementation of Reactive Streams standard

### Gradle

``` Groovy
repositories {
    jcenter()
}

dependencies {
    compile 'com.github.kittinunf.fuel:fuel:<latest-version>' //for JVM
    compile 'com.github.kittinunf.fuel:fuel-android:<latest-version>' //for Android
    compile 'com.github.kittinunf.fuel:fuel-livedata:<latest-version>' //for LiveData support
    compile 'com.github.kittinunf.fuel:fuel-rxjava:<latest-version>' //for RxJava support
    compile 'com.github.kittinunf.fuel:fuel-coroutines:<latest-version>' //for Kotlin Coroutines support
    compile 'com.github.kittinunf.fuel:fuel-gson:<latest-version>' //for Gson support
    compile 'com.github.kittinunf.fuel:fuel-jackson:<latest-version>' //for Jackson support
    compile 'com.github.kittinunf.fuel:fuel-moshi:<latest-version>' //for Moshi support
    compile 'com.github.kittinunf.fuel:fuel-forge:<latest-version>' //for Forge support
    compile 'com.github.kittinunf.fuel:fuel-reactor:<latest-version>' //for Reactor support
}
```

### Sample

* There are two samples, one is in Kotlin and another one in Java.

## Quick Glance Usage

#### Async mode

* Kotlin
```kotlin
//an extension over string (support GET, PUT, POST, DELETE with httpGet(), httpPut(), httpPost(), httpDelete())
"https://httpbin.org/get".httpGet().responseString { request, response, result ->
  //do something with response
  when (result) {
    is Result.Failure -> {
      val ex = result.getException()
    }
    is Result.Success -> {
      val data = result.get()
    }
  }
}

//if we set baseURL beforehand, simply use relativePath
FuelManager.instance.basePath = "https://httpbin.org"
"/get".httpGet().responseString { request, response, result ->
    //make a GET to https://httpbin.org/get and do something with response
    val (data, error) = result
    if (error == null) {
        //do something when success
    } else {
        //error handling
    }
}

//if you prefer this a little longer way, you can always do
//get
Fuel.get("https://httpbin.org/get").responseString { request, response, result ->
	//do something with response
	result.fold({ d ->
	    //do something with data
	}, { err ->
	    //do something with error
	})
}

```

* Java
```java
//get
Fuel.get("https://httpbin.org/get", params).responseString(new Handler<String>() {
    @Override
    public void failure(Request request, Response response, FuelError error) {
    	//do something when it is failure
    }

    @Override
    public void success(Request request, Response response, String data) {
    	//do something when it is successful
    }
});
```

#### Blocking mode
You can also wait for the response. It returns the same parameters as the async version, but it blocks the thread. It supports all the features of the async version.

* Kotlin
```kotlin
val (request, response, result) = "https://httpbin.org/get".httpGet().responseString() // result is Result<String, FuelError>
```

* Java
```java
try {
    Triple<Request, Response, String> data = Fuel.get("https://www.google.com").responseString();
    Request request = data.getFirst();
    Response response = data.getSecond();
    Result<String,FuelError> text = data.getThird();
} catch (Exception networkError) {

}

```

## Detail Usage

### GET

```kotlin
Fuel.get("https://httpbin.org/get").response { request, response, result ->
    println(request)
    println(response)
    val (bytes, error) = result
    if (bytes != null) {
        println(bytes)
    }
}
```

### Response Handling
### Result

* [Result](https://github.com/kittinunf/Result) is a functional style data structure that represents data that contains result of *Success* or *Failure* but not both. It represents the result of an action that can be success (with result) or error.

* Working with result is easy. You could [*fold*](https://github.com/kittinunf/Fuel/blob/master/fuel/src/test/kotlin/com/github/kittinunf/fuel/RequestTest.kt#L324), [*destructure*](https://github.com/kittinunf/Fuel/blob/master/fuel/src/test/kotlin/com/github/kittinunf/fuel/RequestTest.kt#L266) as because it is just a [data class](https://kotlinlang.org/docs/reference/data-classes.html) or do a simple ```when``` checking whether it is *Success* or *Failure*.

### Response
```kotlin
fun response(handler: (Request, Response, Result<ByteArray, FuelError>) -> Unit)
```

### Response in String
```kotlin
fun responseString(handler: (Request, Response, Result<String, FuelError>) -> Unit)
```

### Response in Json
_requires the [android extension](#dependency---fuel-android)_
```kotlin
fun responseJson(handler: (Request, Response, Result<Json, FuelError>) -> Unit)

val jsonObject = json.obj() //JSONObject
val jsonArray = json.array() //JSONArray
```

### Response in T (object)
```kotlin
fun <T> responseObject(deserializer: ResponseDeserializable<T>, handler: (Request, Response, Result<T, FuelError>) -> Unit)
```

### POST

```kotlin
Fuel.post("https://httpbin.org/post").response { request, response, result ->
}

// JSON body from string (automatically sets application/json as Content-Type)
Fuel.post("https://httpbin.org/post")
    .jsonBody("{ \"foo\" : \"bar\" }")
    .response { request, response, result -> }
    
// Body from a generic string
Fuel.post("https://httpbin.org/post")
    .header(Headers.CONTENT_TYPE, "text/plain")
    .body("my body is plain")
    .response { request, response, result -> }
    
// Body from a file
Fuel.post("https://httpbin.org/post")
    .header(Headers.CONTENT_TYPE, "text/plain")
    .body(File("lipsum.txt"))
    .response { request, response, result -> }
    
// Body from a generic stream
val stream = ByteArrayInputStream("source-string-from-string".toByteArray())
Fuel.post("https://httpbin.org/post")
    .header(Headers.CONTENT_TYPE, "text/plain")
    .body(stream)
    .response { request, response, result -> }
```

### PUT

```kotlin
Fuel.put("https://httpbin.org/put")
    .response { request, response, result -> }
    
// Supports all the body methods, like POST requests
```

### DELETE

```kotlin
Fuel.delete("https://httpbin.org/delete")
    .response { request, response, result -> }

// Supports all the body methods, like POST requests
```

### HEAD

```kotlin
Fuel.head("https://httpbin.org/get")
    .response { request, response, result -> /* request body is empty */ }
```

### PATCH
* The default `client` is [`HttpClient`](https://github.com/kittinunf/Fuel/blob/master/fuel/src/main/kotlin/com/github/kittinunf/fuel/toolbox/HttpClient.kt) which is a thin wrapper over [`java.net.HttpUrlConnection`](https://developer.android.com/reference/java/net/HttpURLConnection.html). [`java.net.HttpUrlConnection`](https://developer.android.com/reference/java/net/HttpURLConnection.html) does not support a [`PATCH`](https://download.java.net/jdk7/archive/b123/docs/api/java/net/HttpURLConnection.html#setRequestMethod(java.lang.String)) method. [`HttpClient`](https://github.com/kittinunf/Fuel/blob/master/fuel/src/main/kotlin/com/github/kittinunf/fuel/toolbox/HttpClient.kt) converts `PATCH` requests to a `POST` request and adds a `X-HTTP-Method-Override: PATCH` header. While this is a semi-standard industry practice not all APIs are configured to accept this header by default.

```kotlin
Fuel.patch("https://httpbin.org/patch").response { request, response, result -> }

// Supports all the body methods, like POST requests
```

### CONNECT
Connect is not supported by the Java JVM via the regular HTTP clients, and is therefore not supported.

### OPTIONS
There are no convenience methods for making an OPTIONS request, but you can still make one directly:

```kotlin
Fuel.request(Method.OPTIONS, "https://httpbin.org/anything")
    .response { request, response, result -> }
```

### TRACE
There are no convenience methods for making an TRACE request, but you can still make one directly:

```kotlin
Fuel.request(Method.TRACE, "https://httpbin.org/anything")
    .response { request, response, result -> }
```


### Debug Logging
* Use `toString()` method to inspect requests

```kotlin
val request = Fuel.get("https://httpbin.org/get", parameters = listOf("key" to "value"))
println(request)

// --> GET (https://httpbin.org/get?key=value)
//    Body : (empty)
//    Headers : (2)
//    Accept-Encoding : compress;q=0.5, gzip;q=1.0
//    Device : Android
```

* Use `toString()` method to inspect responses

```kotlin
val (_, response, _) = Fuel.get("https://httpbin.org/get", parameters = listOf("key" to "value")).response()
println(response)
// <-- 200 (https://httpbin.org/get?key=value)
//    Body : (empty)
```

* Also support cUrl string to Log request, make it very easy to cUrl on command line

```kotlin
val request = Fuel.post("https://httpbin.org/post", parameters = listOf("foo" to "foo", "bar" to "bar", "key" to "value"))
println(request.cUrlString())
```

```bash
curl -i -X POST -d "foo=foo&bar=bar&key=value" -H "Accept-Encoding:compress;q=0.5, gzip;q=1.0" -H "Device:Android" -H "Content-Type:application/x-www-form-urlencoded" "https://httpbin.org/post"
```

### Parameter Support

* URL encoded style for GET & DELETE request

```kotlin
Fuel.get("https://httpbin.org/get", listOf("foo" to "foo", "bar" to "bar"))
    .response { request, response, result -> }
// resolve to https://httpbin.org/get?foo=foo&bar=bar
    
Fuel.delete("https://httpbin.org/delete", listOf("foo" to "foo", "bar" to "bar"))
    .response { request, response, result -> }
// resolve to https://httpbin.org/delete?foo=foo&bar=bar
```

* Array support for GET requests

```kotlin
Fuel.get("https://httpbin.org/get", listOf("foo" to "foo", "dwarf" to  arrayOf("grumpy","happy","sleepy","dopey")))
    .response { request, response, result -> }
// resolve to  https://httpbin.org/get?foo=foo&dwarf[]=grumpy&dwarf[]=happy&dwarf[]=sleepy&dwarf[]=dopey
```

* Support x-www-form-urlencoded for PUT & POST

```kotlin
Fuel.post("https://httpbin.org/post", listOf("foo" to "foo", "bar" to "bar"))
    .response { request, response, result -> }
// Body : "foo=foo&bar=bar"

Fuel.put("https://httpbin.org/put", listOf("foo" to "foo", "bar" to "bar"))
    .response { request, response, result -> }
// Body : "foo=foo&bar=bar"
```

### Set request's timeout and read timeout
Default timeout for a request is 15000 milliseconds.
Default read timeout for a request is 15000 milliseconds.

* Kotlin
```kotlin
val timeout = 5000 // 5000 milliseconds = 5 seconds.
val timeoutRead = 60000 // 60000 milliseconds = 1 minute.

Fuel.get("https://httpbin.org/get")
    .timeout(timeout)
    .timeoutRead(timeoutRead)
    .responseString { request, response, result -> }
```

* Java
```java
int timeout = 5000 // 5000 milliseconds = 5 seconds.
int timeoutRead = 60000 // 60000 milliseconds = 1 minute.
Fuel.get("https://httpbin.org/get", params).timeout(timeout).timeoutRead(timeoutRead).responseString(new Handler<String>() {
    @Override
    public void failure(Request request, Response response, FuelError error) {
    	//do something when it is failure
    }

    @Override
    public void success(Request request, Response response, String data) {
    	//do something when it is successful
    }
});
```

### Download with or without progress handler
```kotlin
Fuel.download("https://httpbin.org/bytes/32768")
    .destination { response, url -> File.createTempFile("temp", ".tmp") }
    .response { req, res, result -> }

Fuel.download("https://httpbin.org/bytes/32768")
    .destination { response, url -> File.createTempFile("temp", ".tmp") }
    .progress { readBytes, totalBytes ->
        val progress = readBytes.toFloat() / totalBytes.toFloat() * 100
        println("Bytes downloaded $readBytes / $totalBytes ($progress %)")
    }
    .response { req, res, result -> }
```

### Upload with or without progress handler
```kotlin
Fuel.upload("/post")
    .source { request, url -> File.createTempFile("temp", ".tmp") }
    .responseString { request, response, result -> }

// By default upload use Method.POST, unless it is specified as something else
Fuel.upload("/put", Method.PUT)
    .source { request, url -> File.createTempFile("temp", ".tmp") }
    .responseString { request, response, result -> }

// Upload with multiple files
Fuel.upload("/post")
    .sources { request, url ->
        listOf(
            File.createTempFile("temp1", ".tmp"),
            File.createTempFile("temp2", ".tmp")
        )
    }
    .name { "temp" }
    .responseString { request, response, result -> }
```

### Specify custom field names for files
```Kotlin
Fuel.upload("/post")
    .dataParts { request, url -> 
        listOf( 
            //DataPart takes a file, and you can specify the name and/or type
            DataPart(File.createTempFile("temp1", ".tmp"), "image/jpeg"), 
            DataPart(File.createTempFile("temp2", ".tmp"), "file2"), 
            DataPart(File.createTempFile("temp3", ".tmp"), "third-file", "image/jpeg") 
        ) 
    }
    .responseString { request, response, result -> /* ... */ }
```

### Upload a multipart form without a file
```kotlin
val formData = listOf("Email" to "mail@example.com", "Name" to "Joe Smith" )
Fuel.upload("/post", param = formData)
    // Upload normally requires a file, but we can give it an empty list of `DataPart`
    .dataParts { request, url -> listOf<DataPart>() } 
    .responseString { request, response, result -> /* ... */ }
```
	
### Upload from an `InputStream`

```kotlin
Fuel.upload("/post")
    .blob { request, url -> Blob("filename.png", someObject.length) { someObject.getInputStream() } }
```

### Authentication

* Support *Basic Authentication* right off the box
    ```kotlin
    val username = "username"
    val password = "abcd1234"
    
    Fuel.get("https://httpbin.org/basic-auth/$user/$password")
        .basicAuthentication(username, password)
        .response { request, response, result -> }
    ```

* Support *Bearer Authentication*
    ```kotlin
    val token = "mytoken"
    
    Fuel.get("https://httpbin.org/bearer")
        .bearerAuthentication(token)
        .response { request, response, result -> }
    ```

* Support *Any authentication* by header
    ```kotlin
    Fuel.get("https://httpbin.org/anything")
        .header(Headers.AUTHORIZATION, "Custom secret")
        .response { request, response, result -> }
    ```

### Validation

* By default, the valid range for HTTP status code will be (200..299).

### Cancel

* If one wants to cancel on-going request, one could call `cancel` on the request object
    ```kotlin
    val request = Fuel.get("https://httpbin.org/get")
      .response { request, response, result ->
        // if request is cancelled successfully, response callback will not be called. 
        // Interrupt callback (if provided) will be called instead
      }
    
    //later
    request.cancel() //this will cancel on-going request
    ```

* Also, interrupt request can be further processed with interrupt callback
    ```kotlin
    val request = Fuel.get("https://httpbin.org/get")
      .interrupt { request -> println("${request.url} was interrupted and cancelled") }
      .response { request, response, result ->
        // if request is cancelled successfully, response callback will not be called.
        // Interrupt callback (if provided) will be called instead
      }
 
    request.cancel()
    ```

## Advanced Configuration

### Response Deserialization

* Fuel provides built-in support for response deserialization. Here is how one might want to use Fuel together with [Gson](https://github.com/google/gson)
```kotlin
//User Model
data class User(val firstName: String = "",
                val lastName: String = "") {

    //User Deserializer
    class Deserializer : ResponseDeserializable<User> {
        override fun deserialize(content: String) = Gson().fromJson(content, User::class.java)
    }

}

//Use httpGet extension
"https://www.example.com/user/1".httpGet().responseObject(User.Deserializer()) { req, res, result ->
    //result is of type Result<User, Exception>
    val (user, err) = result

    println(user.firstName)
    println(user.lastName)
}

```

### Gson Deserialization

* Fuel also provides a built in support for Gson Deserialization. This is possible by including the [Gson](https://github.com/kittinunf/Fuel/tree/master/fuel-gson) module in your dependency block.

```kotlin
data class HttpBinUserAgentModel(var userAgent: String = "")
Fuel.get("/user-agent")
    .responseObject<HttpBinUserAgentModel> { _, _, result -> }
```

### Deserialization using kotlinx.serialzationn

_requires the [kotlinx-serialization extension](#dependency---fuel-kotlinx-serialization)_
_requires [kotlinx.serialization](https://github.com/Kotlin/kotlinx.serialization#gradlejvm)_


```kotlin
@Serializable
data class HttpBinUserAgentModel(var userAgent: String = "")

Fuel.get("/user-agent")
    .responseObject<HttpBinUserAgentModel> { _, _, result -> }
```

This is by default strict and will reject unknown keys, for that you can pass a custom JSOn instance

`JSON(nonstrict = true)`
```kotlin
@Serializable
data class HttpBinUserAgentModel(var userAgent: String = "")

Fuel.get("/user-agent")
    .responseObject<HttpBinUserAgentModel>(json = JSON(nonstrict = true)) { _, _, result -> }
```

`kotlinx.serialization` can not always guess the correct serialzer to use, when generics are involved for example

```kotlin
@Serializable
data class HttpBinUserAgentModel(var userAgent: String = "")

Fuel.get("/list/user-agent")
    .responseObject<HttpBinUserAgentModel>(loader = HttpBinUserAgentModel.serilaizer().list) { _, _, result -> }
```

It can be used with coroutines by using `kotlinxDeserilaizerOf()` it takes the same `json` and `loader` as parameters

```kotlin
@Serializable
data class HttpBinUserAgentModel(var userAgent: String = "")

Fuel.get("/user-agent")
    .awaitResponseObject<HttpBinUserAgentModel>(kotlinxDeserializerOf()) { _, _, result -> }
```

* There are 4 methods to support response deserialization depending on your needs (also depending on JSON parsing library of your choice), and you are required to implement only one of them.

    ```kotlin
    fun deserialize(bytes: ByteArray): T?
    
    fun deserialize(inputStream: InputStream): T?
    
    fun deserialize(reader: Reader): T?
    
    fun deserialize(content: String): T?
    ```

* Another example may be parsing a website that is not UTF-8. By default, Fuel serializes text as UTF-8, we need to define our deserializer as such
    
    ```kotlin
    object Windows1255StringDeserializer : ResponseDeserializable<String> {
        override fun deserialize(bytes: ByteArray): String {
            return String(bytes, "windows-1255")
        }
    }
    ```
    
### Configuration

* Use singleton `FuelManager.instance` to manage global configurations.

* `basePath` is used to manage common root path. Great usage is for your static API endpoint.
    ```kotlin
    FuelManager.instance.basePath = "https://httpbin.org"
    
    // Later
    Fuel.get("/get").response { request, response, result ->
        //make request to https://httpbin.org/get because Fuel.{get|post|put|delete} use FuelManager.instance to make HTTP request
    }
    ```

* `baseHeaders` is to manage common HTTP header pairs in format of `Map<String, String>`. 
    - The base headers are only applied if the request does not have those headers set.
    ```kotlin
    FuelManager.instance.baseHeaders = mapOf("Device" to "Android")
    ```

* `Headers` can be added to a request via various methods including
    - `fun header(name: String, value: Any): Request`: `request.header("foo", "a")`
    - `fun header(pairs: Map<String, Any>): Request`: `request.header(mapOf("foo" to "a"))`
    - `fun header(vararg pairs: Pair<String, Any>): Request`: `request.header("foo" to "a")`
    - `operator fun set(header: String, value: Collection<Any>): Request`: `request["foo"] = listOf("a", "b")`
    - `operator fun set(header: String, value: Any): Request`: `request["foo"] = "a"`
* By default, all subsequent calls overwrite earlier calls, but you may use the `appendHeader` variant to append values to existing values.
    - In earlier versions a `mapOf` overwrote, and `varargs pair` did not, but this was confusing.
* Some of the HTTP headers are defined under `Headers.Companion` and can be used instead of literal strings.
    ```kotlin
    Fuel.post("/my-post-path")
        .header(Headers.ACCEPT, "text/html, */*; q=0.1")
        .header(Headers.CONTENT_TYPE, "image/png")
        .header(Headers.COOKIE to "basic=very")
        .appendHeader(Headers.COOKIE to "value_1=foo", Headers.COOKIE to "value_2=bar", Headers.ACCEPT to "application/json")
        .appendHeader("MyFoo" to "bar", "MyFoo" to "baz")
        .response { /*...*/ }
        
     // => request with:
     //    Headers:
     //      Accept: "text/html, */*; q=0.1, application/json"
     //      Content-Type: "image/png"
     //      Cookie: "basic=very; value_1=foo; value_2=bar"
     //      MyFoo: "bar, baz"
    ```

* `baseParams` is used to manage common `key=value` query param, which will be automatically included in all of your subsequent requests in format of ` Parameters` (`Any` is converted to `String` by `toString()` method)
    ```kotlin
    FuelManager.instance.baseParams = listOf("api_key" to "1234567890")
    
    // Later
    Fuel.get("/get").response { request, response, result ->
        //make request to https://httpbin.org/get?api_key=1234567890
    }
    ```

* `client` is a raw HTTP client driver. Generally, it is responsible to make [`Request`](https://github.com/kittinunf/Fuel/blob/master/fuel/src/main/kotlin/fuel/core/Request.kt) into [`Response`](https://github.com/kittinunf/Fuel/blob/master/fuel/src/main/kotlin/fuel/core/Response.kt). Default is [`HttpClient`](https://github.com/kittinunf/Fuel/blob/master/fuel/src/main/kotlin/fuel/toolbox/HttpClient.kt) which is a thin wrapper over [`java.net.HttpUrlConnection`](https://developer.android.com/reference/java/net/HttpURLConnection.html). You could use any httpClient of your choice by conforming to [`client`](https://github.com/kittinunf/Fuel/blob/master/fuel/src/main/kotlin/com/github/kittinunf/fuel/core/Client.kt) protocol, and set back to `FuelManager.instance` to kick off the effect.

* `keyStore` is configurable by user. By default it is `null`.

* `socketFactory` can be supplied by user. If `keyStore` is not null, `socketFactory` will be derived from it.

* `hostnameVerifier` is configurable by user. By default, it uses `HttpsURLConnection.getDefaultHostnameVerifier()`.

* `requestInterceptors` `responseInterceptors` is a side-effect to add to `Request` and/or `Response` objects. 
    - For example, one might wanna print cUrlString style for every request that hits server in DEBUG mode.
        ```kotlin
        val manager = FuelManager()
        if (BUILD_DEBUG) {
            manager.addRequestInterceptor(cUrlLoggingRequestInterceptor())
        }
        val (request, response, result) = manager.request(Method.GET, "https://httpbin.org/get").response() //it will print curl -i -H "Accept-Encoding:compress;q=0.5, gzip;q=1.0" "https://httpbin.org/get"
        ```

    - Another example is that you might wanna add data into your Database, you can achieve that with providing `responseInterceptors` such as

        ```kotlin
        inline fun <reified T> DbResponseInterceptor() =
            { next: (Request, Response) -> Response ->
                { req: Request, res: Response ->
                    val db = DB.getInstance()
                    val instance = Parser.getInstance().parse(res.data, T::class)
                    db.transaction {
                        it.copyToDB(instance)
                    }
                    next(req, res)
                }
            }
        
        manager.addResponseInterceptor(DBResponseInterceptor<Dog>)
        manager.request(Method.GET, "https://www.example.com/api/dog/1").response() // Db interceptor will be called to intercept data and save into Database of your choice
        ```

### Test mode

Testing asynchronized calls can be somehow hard without special care. That's why Fuel has a special test mode with make all the requests blocking, for tests.

```kotlin
Fuel.testMode {
    timeout = 15000 // Optional feature, set all requests' timeout to this value.
}
```

In order to disable test mode, just call `Fuel.regularMode()`

### RxJava Support

* Fuel supports [RxJava](https://github.com/ReactiveX/RxJava) right off the box.
    ```kotlin
    "https://www.example.com/photos/1".httpGet()
      .toRxObject(Photo.Deserializer())
      .subscribe { /* do something */ }
    ```

* There are 6 extensions over `Request` that provide RxJava 2.x `Single<Result<T, FuelError>>` as return type.
    ```kotlin
    fun Request.toRxResponse(): Single<Pair<Response, Result<ByteArray, FuelError>>>
    fun Request.toRxResponseString(charset: Charset): Single<Pair<Response, Result<String, FuelError>>>
    fun <T : Any> Request.toRxResponseObject(deserializable: Deserializable<T>): Single<Pair<Response, Result<T, FuelError>>>
    
    fun Request.toRxData(): Single<Result<ByteArray, FuelError>>
    fun Request.toRxString(charset: Charset): Single<Result<String, FuelError>>
    fun <T : Any> Request.toRxObject(deserializable: Deserializable<T>): Single<Result<T, FuelError>>
    ```

### LiveData Support

* Fuel supports [LiveData](https://developer.android.com/topic/libraries/architecture/livedata.html)
```kotlin
Fuel.get("www.example.com/get")
    .liveDataResponse()
    .observe(this) { /* do something */ }
```

### Routing Support

In order to organize better your network stack FuelRouting interface allows you to easily setup a Router design pattern.

```Kotlin
sealed class WeatherApi: FuelRouting {

    override val basePath = "https://www.metaweather.com"

    class weatherFor(val location: String): WeatherApi() {}

    override val method: Method
        get() {
            when(this) {
                is weatherFor -> return Method.GET
            }
        }

    override val path: String
        get() {
            return when(this) {
                is weatherFor -> "/api/location/search/"
            }
        }

    override val params: Parameters?
        get() {
            return when(this) {
                is weatherFor -> listOf("query" to this.location)
            }
        }

    override val headers: Map<String, String>?
        get() {
            return null
        }

}


// Usage
Fuel.request(WeatherApi.weatherFor("london"))
    .responseJson { request, response, result ->
        result.fold(success = { json ->
            Log.d("qdp success", json.array().toString())
        }, failure = { error ->
            Log.e("qdp error", error.toString())
        })
    }
```

### Coroutines Support

Coroutines module provides extension functions to wrap a response inside a coroutine and handle its result. The coroutines-based API provides equivalent methods to the standard API (e.g: `responseString()` in coroutines is `awaitStringResponse()`).

```kotlin
runBlocking {
    val (request, response, result) = Fuel.get("https://httpbin.org/ip").awaitStringResponse()

    result.fold(
        { data -> println(data) /* "{"origin":"127.0.0.1"}" */ }, 
        { error -> println("An error of type ${error.exception} happened: ${error.message}") }
    )
}
```

There are functions to handle `Result` object directly too.

```kotlin
runBlocking {
    Fuel.get("https://httpbin.org/ip")
        .awaitStringResult()
        .fold(
            { data -> println(data) /* "{"origin":"127.0.0.1"}" */ }, 
            { error -> println("An error of type ${error.exception} happened: ${error.message}") }
        )
}
```

It also provides useful methods to retrieve the `ByteArray`,`String` or `Object` directly. The difference with these implementations is that they throw exception instead of returning it wrapped a `FuelError` instance.

```kotlin
runBlocking {
    try {
        println(Fuel.get("https://httpbin.org/ip").awaitString()) // "{"origin":"127.0.0.1"}"
    } catch(exception: Exception) {
        println("A network request exception was thrown: ${exception.message}")
    }
}
```

Handling objects other than `String` (`awaitStringResponse() `) or `ByteArray` (`awaitByteArrayResponse()`) can be done using `awaitObject`, `awaitObjectResult` or `awaitObjectResponse`.

```kotlin
data class Ip(val origin: String)

object IpDeserializer : ResponseDeserializable<Ip> {
    override fun deserialize(content: String) =
        jacksonObjectMapper().readValue<Ip>(content)
}
```

```kotlin
runBlocking {
    Fuel.get("https://httpbin.org/ip")
        .awaitObjectResult(IpDeserializer)
        .fold(
            { data -> println(data.origin) /* 127.0.0.1 */ }, 
            { error -> println("An error of type ${error.exception} happened: ${error.message}") }
        )
}
```

```kotlin
runBlocking {
    try {
        val data = Fuel.get("https://httpbin.org/ip").awaitObject(IpDeserializer)
        println(data.origin) // 127.0.0.1
    } catch (exception: Exception) {
        when (exception){
            is HttpException -> println("A network request exception was thrown: ${exception.message}")
            is JsonMappingException -> println("A serialization/deserialization exception was thrown: ${exception.message}")
            else -> println("An exception [${exception.javaClass.simpleName}\"] was thrown")
        }
    }
}
```

### Project Reactor

The Reactor module API provides functions starting with the prefix `mono` to handle instances of `Response`, `Result<T, FuelError>` and values directly (`String`, `ByteArray`, `Any`). All functions expose exceptions as `FuelError` instance.

**Data handling example**

```kotlin
Fuel.get("https://icanhazdadjoke.com")
    .header(Headers.ACCEPT to "text/plain")
    .monoString()
    .subscribe(::println)
```

**Error handling example**

```kotlin
data class Guest(val name: String)

object GuestMapper : ResponseDeserializable<Guest> {
    override fun deserialize(content: String) =
        jacksonObjectMapper().readValue<Guest>(content)
}

Fuel.get("/guestName").monoResultObject(GuestMapper)
    .map(Result<Guest, FuelError>::get)
    .map { (name) -> "Welcome to the party, $name!" }
    .onErrorReturn("I'm sorry, your name is not on the list.")
    .subscribe(::println)
```

**Response handling example**

```kotlin
FuelManager.instance.basePath = "https://httpbin.org"

Fuel.get("/status/404").monoResponse()
    .filter(Response::isSuccessful)
    .switchIfEmpty(Fuel.get("/status/200").monoResponse())
    .map(Response::statusCode)
    .subscribe(::println)
```

## Other libraries
If you like Fuel, you might also like other libraries of mine;
* [Result](https://github.com/kittinunf/Result) - The modelling for success/failure of operations in Kotlin
* [Fuse](https://github.com/kittinunf/Fuse) - A simple generic LRU memory/disk cache for Android written in Kotlin
* [Forge](https://github.com/kittinunf/Forge) - Functional style JSON parsing written in Kotlin
* [ReactiveAndroid](https://github.com/kittinunf/ReactiveAndroid) - Reactive events and properties with RxJava for Android SDK

## Credits

Fuel is brought to you by [contributors](https://github.com/kittinunf/Fuel/graphs/contributors).

## Licenses

Fuel is released under the [MIT](https://opensource.org/licenses/MIT) license.
