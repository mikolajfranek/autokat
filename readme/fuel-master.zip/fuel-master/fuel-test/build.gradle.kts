dependencies {
    api(project(Fuel.name))

    api(MockServer.dependency)
    implementation(Json.dependency)
}
